package com.rocketcraft;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * Física inspirada no Rocket League. Unidades: 1 bloco = 100 unreal units (uu).
 * Todas as constantes abaixo estão em blocos e segundos.
 */
public class RocketCraft implements ModInitializer {
    static final double DT = 0.05;              // 1 tick
    static final double GRAVITY = 6.5;          // 650 uu/s²
    static final double BALL_R = 0.9125;        // raio 91.25 uu
    static final double BALL_MAX = 60;          // 6000 uu/s
    static final double BALL_REST = 0.6;        // quique
    static final double BALL_DRAG = 0.03;       // amortecimento /s
    static final double HIT_GAIN = 1.9;         // ganho do impacto carro->bola (ajuste aqui)
    static final double CAR_MAX = 23;           // 2300 uu/s
    static final double THROTTLE_MAX_SPEED = 14.1;
    static final double THROTTLE_ACC = 16;      // 1600 uu/s²
    static final double BRAKE_ACC = 35;
    static final double COAST_ACC = 5.25;
    static final double BOOST_ACC = 9.917;      // 991.67 uu/s²
    static final double BOOST_USE = 33.3;       // % por segundo
    // Hitbox Octane/Fennec (meios-tamanhos): 118 x 84 x 36 uu
    static final double HL = 0.59, HW = 0.42, HH = 0.18;

    static Ball ball;
    static final List<Car> cars = new ArrayList<>();

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((d, reg, env) -> d.register(
            CommandManager.literal("rl")
                .then(CommandManager.literal("ball").executes(c -> spawnBall(c.getSource())))
                .then(CommandManager.literal("octane").executes(c -> spawnCar(c.getSource(), "minecraft:orange_concrete")))
                .then(CommandManager.literal("fennec").executes(c -> spawnCar(c.getSource(), "minecraft:black_concrete")))
                .then(CommandManager.literal("clear").executes(c -> { clear(); return 1; }))));
        ServerTickEvents.END_SERVER_TICK.register(s -> tick());
    }

    static void clear() {
        if (ball != null) ball.e.discard();
        ball = null;
        cars.forEach(Car::remove);
        cars.clear();
    }

    static int spawnBall(ServerCommandSource src) {
        if (ball != null) ball.e.discard();
        ServerWorld w = src.getWorld();
        SlimeEntity s = EntityType.SLIME.create(w, SpawnReason.COMMAND);
        s.setSize(4, true);
        s.setAiDisabled(true); s.setNoGravity(true); s.setSilent(true); s.setInvulnerable(true);
        s.getAttributeInstance(EntityAttributes.SCALE).setBaseValue(0.877);       // 2.08 -> 1.825 blocos (ø 182.5 uu)
        s.getAttributeInstance(EntityAttributes.STEP_HEIGHT).setBaseValue(0);
        Vec3d p = src.getPosition();
        s.setPosition(p.x, p.y + 3, p.z);
        w.spawnEntity(s);
        ball = new Ball(s);
        return 1;
    }

    static int spawnCar(ServerCommandSource src, String block) {
        ServerPlayerEntity p;
        try { p = src.getPlayerOrThrow(); } catch (Exception ex) { return 0; }
        ServerWorld w = src.getWorld();
        ArmorStandEntity s = EntityType.ARMOR_STAND.create(w, SpawnReason.COMMAND);
        s.setInvisible(true); s.setNoGravity(true); s.setInvulnerable(true); s.setSilent(true);
        s.getAttributeInstance(EntityAttributes.STEP_HEIGHT).setBaseValue(0);
        s.setPosition(p.getX(), p.getY(), p.getZ());
        w.spawnEntity(s);
        UUID id = UUID.randomUUID();
        long m = id.getMostSignificantBits(), l = id.getLeastSignificantBits();
        String cmd = String.format(Locale.ROOT,
            "summon block_display %f %f %f {UUID:[I;%d,%d,%d,%d],teleport_duration:3,block_state:{Name:\"%s\"},"
            + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
            + "translation:[%ff,0f,%ff],scale:[%ff,%ff,%ff]}}",
            p.getX(), p.getY(), p.getZ(), (int) (m >> 32), (int) m, (int) (l >> 32), (int) l, block,
            -HW, -HL, HW * 2, HH * 2, HL * 2);
        src.getServer().getCommandManager().executeWithPrefix(src.withSilent(), cmd);
        p.startRiding(s, true);
        cars.add(new Car(w, s, id, p));
        return 1;
    }

    static void tick() {
        cars.removeIf(c -> { if (c.tick()) return false; c.remove(); return true; });
        if (ball != null) {
            if (!ball.e.isAlive()) { ball = null; return; }
            for (Car c : cars) c.hitBall(ball);
            ball.tick();
        }
    }

    static Vec3d fwd(float yaw) {
        double r = Math.toRadians(yaw);
        return new Vec3d(-Math.sin(r), 0, Math.cos(r));
    }

    // curvatura (1/bloco) x velocidade (bloco/s), tabela do RL
    static final double[] SPD = {0, 5, 10, 15, 17.5, 23};
    static final double[] CUR = {0.69, 0.398, 0.235, 0.1375, 0.11, 0.088};
    static double curvature(double s) {
        s = Math.min(Math.abs(s), 23);
        for (int i = 1; i < SPD.length; i++)
            if (s <= SPD[i]) return MathHelper.lerp((s - SPD[i - 1]) / (SPD[i] - SPD[i - 1]), CUR[i - 1], CUR[i]);
        return CUR[CUR.length - 1];
    }

    static class Ball {
        final SlimeEntity e; Vec3d v = Vec3d.ZERO;
        Ball(SlimeEntity e) { this.e = e; }
        Vec3d center() { return e.getPos().add(0, BALL_R, 0); }
        void tick() {
            v = v.add(0, -GRAVITY * DT, 0).multiply(1 - BALL_DRAG * DT);
            double sp = v.length(); if (sp > BALL_MAX) v = v.multiply(BALL_MAX / sp);
            Vec3d want = v.multiply(DT), before = e.getPos();
            e.move(MovementType.SELF, want);
            Vec3d d = e.getPos().subtract(before);
            double x = v.x, y = v.y, z = v.z;
            if (Math.abs(d.x) < Math.abs(want.x) - 1e-4) x = -x * BALL_REST;
            if (Math.abs(d.z) < Math.abs(want.z) - 1e-4) z = -z * BALL_REST;
            if (Math.abs(d.y) < Math.abs(want.y) - 1e-4) {
                y = Math.abs(y) < 1.0 ? 0 : -y * BALL_REST;
                if (want.y < 0) { x *= 0.995; z *= 0.995; }   // atrito de rolagem
            }
            v = new Vec3d(x, y, z);
        }
    }

    static class Car {
        final ServerWorld w; final ArmorStandEntity s; final UUID disp; final ServerPlayerEntity driver;
        Vec3d v = Vec3d.ZERO; float yaw; double boost = 33, jumpT; boolean ground, wasJump; int age;
        Car(ServerWorld w, ArmorStandEntity s, UUID disp, ServerPlayerEntity d) {
            this.w = w; this.s = s; this.disp = disp; this.driver = d; this.yaw = d.getYaw();
        }
        void remove() {
            s.discard();
            Entity d = w.getEntity(disp); if (d != null) d.discard();
        }
        Vec3d center() { return s.getPos().add(0, HH, 0); }

        /** @return false se o carro deve ser removido */
        boolean tick() {
            age++;
            if (!s.isAlive() || driver.isRemoved() || (age > 10 && s.getFirstPassenger() != driver)) return false;
            PlayerInput in = driver.getPlayerInput();
            double t = (in.forward() ? 1 : 0) - (in.backward() ? 1 : 0);
            double st = (in.right() ? 1 : 0) - (in.left() ? 1 : 0);
            boolean boosting = in.sprint() && boost > 0;
            double aBoost = boosting ? BOOST_ACC : 0;
            if (boosting) boost -= BOOST_USE * DT; else boost = Math.min(100, boost + 8 * DT);

            Vec3d fw = fwd(yaw), h = new Vec3d(v.x, 0, v.z);
            if (ground) {
                double f = h.dotProduct(fw);
                Vec3d lat = h.subtract(fw.multiply(f));
                double a;
                if (t != 0) a = (t * f >= 0) ? t * THROTTLE_ACC * Math.max(0, 1 - Math.abs(f) / THROTTLE_MAX_SPEED) : t * BRAKE_ACC;
                else a = -Math.signum(f) * Math.min(Math.abs(f) / DT, COAST_ACC);
                f += (a + aBoost) * DT;
                f = MathHelper.clamp(f, -CAR_MAX, CAR_MAX);
                yaw += (float) Math.toDegrees(st * f * curvature(f) * DT);
                fw = fwd(yaw);
                h = fw.multiply(f).add(lat.multiply(0.1));
            } else {
                yaw += (float) Math.toDegrees(st * 4.0 * DT);
                fw = fwd(yaw);
                h = h.add(fw.multiply(aBoost * DT));
                double sp = h.length(); if (sp > CAR_MAX) h = h.multiply(CAR_MAX / sp);
            }
            double y = v.y;
            boolean jump = in.jump();
            if (jump && !wasJump && ground) { y = 2.92; jumpT = 0.2; }
            else if (jump && jumpT > 0) { y += 14.58 * DT; jumpT -= DT; }
            if (!jump) jumpT = 0;
            wasJump = jump;
            y -= GRAVITY * DT;
            v = new Vec3d(h.x, y, h.z);

            Vec3d want = v.multiply(DT), before = s.getPos();
            s.move(MovementType.SELF, want);
            Vec3d d = s.getPos().subtract(before);
            double vx = v.x, vy = v.y, vz = v.z;
            if (Math.abs(d.x) < Math.abs(want.x) - 1e-4) vx = 0;
            if (Math.abs(d.z) < Math.abs(want.z) - 1e-4) vz = 0;
            ground = false;
            if (Math.abs(d.y) < Math.abs(want.y) - 1e-4) { ground = want.y < 0; vy = 0; }
            v = new Vec3d(vx, vy, vz);

            s.setYaw(yaw); s.setBodyYaw(yaw);
            Entity dp = w.getEntity(disp);
            if (dp != null) { dp.setPosition(s.getPos()); dp.setYaw(yaw); }
            driver.sendMessage(Text.literal("Boost " + (int) boost + "%  " + (int) (v.length() * 100) + " uu/s"), true);
            return true;
        }

        void hitBall(Ball b) {
            Vec3d c = center(), fw = fwd(yaw), side = new Vec3d(Math.cos(Math.toRadians(yaw)), 0, Math.sin(Math.toRadians(yaw)));
            Vec3d bc = b.center(), d = bc.subtract(c);
            double cx = MathHelper.clamp(d.dotProduct(side), -HW, HW);
            double cy = MathHelper.clamp(d.y, -HH, HH);
            double cz = MathHelper.clamp(d.dotProduct(fw), -HL, HL);
            Vec3d closest = c.add(side.multiply(cx)).add(0, cy, 0).add(fw.multiply(cz));
            Vec3d diff = bc.subtract(closest);
            double dist = diff.length();
            if (dist >= BALL_R || dist < 1e-6) return;
            Vec3d n = diff.multiply(1 / dist);
            n = new Vec3d(n.x, n.y * 0.35, n.z).normalize();       // amortecimento vertical do RL
            double relN = b.v.subtract(v).dotProduct(n);
            if (relN < 0) b.v = b.v.subtract(n.multiply(relN * HIT_GAIN));
            double sp = b.v.length(); if (sp > BALL_MAX) b.v = b.v.multiply(BALL_MAX / sp);
            b.e.setPosition(b.e.getPos().add(diff.multiply((BALL_R - dist) / dist)));
        }
    }
}
